cd /home/fisco-bcos/generator-A/nodeA
rm -rf sdk
mkdir sdk
cp node_127.0.0.1_30300/conf/ca.crt sdk/
cp node_127.0.0.1_30300/conf/node.crt sdk/
cp node_127.0.0.1_30300/conf/node.key sdk/

# next as you need to change webase's configuration file common.properties, make sure node's  
# ip and ports are correct, as you are using new generated blockchain, if.exist.fisco=yes, and
# change the fisco.dir and node.dir accordingly.

cp /home/fisco-bcos/Downloads/common.properties /home/fisco-bcos/webase-deploy

echo "###################################################################"
echo "Successfully configured WeBASE property files                      "
echo "###################################################################"
