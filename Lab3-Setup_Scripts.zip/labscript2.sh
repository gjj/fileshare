echo "###################################################################" >> ~/webase-deploy/lab32.log
echo "# Generate Agency A node                                           " >> ~/webase-deploy/lab32.log
echo "###################################################################" >> ~/webase-deploy/lab32.log
echo "Agency A(Bank) node"  
echo "Agency A(Bank) node                                                " >> ~/webase-deploy/lab32.log  
echo "-------------------------------------------------------------------" >> ~/webase-deploy/lab32.log
cd ~/generator-A
cp /home/fisco-bcos/Downloads/genA_node_deployment.ini ~/generator-A/conf/node_deployment.ini
echo "Successfully Modified generator A node_deployment.ini              " >> ~/webase-deploy/lab32.log
echo "---                                                                " >> ~/webase-deploy/lab32.log
cp /home/fisco-bcos/Downloads/genA_group_genesis.ini ~/generator-A/conf/group_genesis.ini
echo "Successfully Modified group_genesis.ini                            " >> ~/webase-deploy/lab32.log
echo "---                                                                " >> ~/webase-deploy/lab32.log
cp conf/group_genesis.ini ~/generator-B/meta/
cp conf/group_genesis.ini ~/generator-C/meta/
echo "Successfully copied group_genesis.ini to generator-B &generator-C  " >> ~/webase-deploy/lab32.log
echo "---                                                                " >> ~/webase-deploy/lab32.log
./generator --generate_all_certificates ./agencyA_node_info
echo "Successfully generated node information                            " >> ~/webase-deploy/lab32.log
echo "---                                                                " >> ~/webase-deploy/lab32.log
cp ./agencyA_node_info/peers.txt ~/generator-B/meta/peersA.txt
cp ./agencyA_node_info/peers.txt ~/generator-C/meta/peersA.txt
echo "Successfully copied node information to other two agency           " >> ~/webase-deploy/lab32.log
echo "---                                                                " >> ~/webase-deploy/lab32.log

echo "###################################################################" >> ~/webase-deploy/lab32.log
echo "# Generate Agency B node                                           " >> ~/webase-deploy/lab32.log
echo "###################################################################" >> ~/webase-deploy/lab32.log
echo "Agency B(Manufacturer) node"  
echo "Agency B(Manufacturer) node"  
echo "--------------------------------------------------------------------" >> ~/webase-deploy/lab32.log
cd ~/generator-B
cp /home/fisco-bcos/Downloads/genB_node_deployment.ini ~/generator-B/conf/node_deployment.ini
echo "Successfully Modified generator B node_deployment.ini              " >> ~/webase-deploy/lab32.log
echo "---                                                                " >> ~/webase-deploy/lab32.log
./generator --generate_all_certificates ./agencyB_node_info
echo "Copy the manufacturer's cert file & node info to the bank direcory " >> ~/webase-deploy/lab32.log
echo "---                                                                " >> ~/webase-deploy/lab32.log
cp ./agencyB_node_info/cert*.crt ~/generator-A/meta/
cp ./agencyB_node_info/peers.txt ~/generator-A/meta/peersB.txt

echo "###################################################################" >> ~/webase-deploy/lab32.log
echo "# Generate Agency C node                                           " >> ~/webase-deploy/lab32.log
echo "###################################################################" >> ~/webase-deploy/lab32.log
echo "Agency C(Supplier) node"  
echo "Agency C(Supplier) node"
echo "--------------------------------------------------------------------" >> ~/webase-deploy/lab32.log
cd ~/generator-C
cp /home/fisco-bcos/Downloads/genC_node_deployment.ini ~/generator-C/conf/node_deployment.ini
echo "Successfully Modified generator C node_deployment.ini              " >> ~/webase-deploy/lab32.log
echo "---                                                                 " >> ~/webase-deploy/lab32.log
./generator --generate_all_certificates ./agencyC_node_info
cp ./agencyC_node_info/cert*.crt ~/generator-A/meta/
cp ./agencyC_node_info/peers.txt ~/generator-A/meta/peersC.txt
echo "Successfully copied bank node information to the bank directory    " >> ~/webase-deploy/lab32.log
echo "---                                                                " >> ~/webase-deploy/lab32.log

echo "###################################################################"
echo "Successfully executed the script file labscript2.sh                "
echo "###################################################################"
echo "Now execute the script file labscript3.sh                          "
echo "###################################################################"
