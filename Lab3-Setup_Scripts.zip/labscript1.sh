rm -rf /home/fisco-bcos/generator
rm -rf /home/fisco-bcos/generator-A
rm -rf /home/fisco-bcos/generator-B
rm -rf /home/fisco-bcos/generator-C
cd /home/fisco-bcos/webase-deploy
echo "####################################################################" > lab3.log
echo "# Enterprise-level deployment tools.                                " >> lab3.log
echo "####################################################################" >> lab3.log
cd /home/fisco-bcos/webase-deploy
echo "Successfully downloaded Generator                                   " >> lab3.log
cd ~/ && git clone https://github.com/FISCO-BCOS/generator.git
echo "---                                                                 " >> ~/webase-deploy/lab3.log
echo "Installing the generator.                                           " >> ~/webase-deploy/lab3.log
cd ~/generator && bash ./scripts/install.sh
echo "Successfully installed generator installtion                        " >> ~/webase-deploy/lab3.log
echo "---                                                                 " >> ~/webase-deploy/lab3.log
echo "Download the FISCO BCOS binary file.                                " >> ~/webase-deploy/lab3.log
./generator --download_fisco ./meta

echo "####################################################################" >> ~/webase-deploy/lab3.log
echo "# Generate blockchain certificate and angency certificate.          " >> ~/webase-deploy/lab3.log
echo "####################################################################" >> ~/webase-deploy/lab3.log
cp -r ~/generator ~/generator-A
cp -r ~/generator ~/generator-B
cp -r ~/generator ~/generator-C
echo "Successfully copied generator A, B, C                               " >> ~/webase-deploy/lab3.log
echo "---                                                                 " >> ~/webase-deploy/lab3.log
cd ~/generator && ./generator --generate_chain_certificate ./dir_chain_ca
echo "Successfully generated the blockchain certificate                   " >> ~/webase-deploy/lab3.log
echo "---                                                                 " >> ~/webase-deploy/lab3.log
ls ./dir_chain_ca
echo "Successfully executed ls ./dir_chain_ca                             " >> ~/webase-deploy/lab3.log
echo "---                                                                 " >> ~/webase-deploy/lab3.log

echo "####################################################################" >> ~/webase-deploy/lab3.log
echo "# Generate the Bank certificate.                                    " >> ~/webase-deploy/lab3.log
echo "####################################################################" >> ~/webase-deploy/lab3.log
echo "# Generate the blockchain certificate.                              " >> ~/webase-deploy/lab3.log
echo "Prepare the certificates for banks                                  " >> ~/webase-deploy/lab3.log
./generator --generate_agency_certificate ./dir_agency_ca ./dir_chain_ca agencyA
echo "Successfully generated agencyA certificate                          " >> ~/webase-deploy/lab3.log
echo "---                                                                 " >> ~/webase-deploy/lab3.log
cp ./dir_agency_ca/agencyA/* ~/generator-A/meta/
echo "Successfully copied agencyA certificate to the deployment folder.   " >> ~/webase-deploy/lab3.log
echo "---                                                                 " >> ~/webase-deploy/lab3.log

echo "####################################################################" >> ~/webase-deploy/lab3.log
echo "# Generate the car manufacturer certificate                         " >> ~/webase-deploy/lab3.log
echo "####################################################################" >> ~/webase-deploy/lab3.log
./generator --generate_agency_certificate ./dir_agency_ca ./dir_chain_ca agencyB
echo "Successfully generated agencyB certificate                         " >> ~/webase-deploy/lab3.log
echo "---                                                                 " >> ~/webase-deploy/lab3.log
echo "Copy the certificate to the deployment folder.                     " >> ~/webase-deploy/lab3.log
cp ./dir_agency_ca/agencyB/* ~/generator-B/meta/
echo "Successfully Copied agencyB certificate to the deployment folder.  " >> ~/webase-deploy/lab3.log
echo "---                                                                 " >> ~/webase-deploy/lab3.log

echo "####################################################################" >> ~/webase-deploy/lab3.log
echo "# Generate the supplier certificate                                 " >> ~/webase-deploy/lab3.log
echo "####################################################################" >> ~/webase-deploy/lab3.log
echo "Generate the supplier certificate"
./generator --generate_agency_certificate ./dir_agency_ca ./dir_chain_ca agencyC
echo "Successfully generated agencyC certificate                         " >> ~/webase-deploy/lab3.log
echo "---                                                                 " >> ~/webase-deploy/lab3.log
echo "Copy the certificate to the deployment folder."
cp ./dir_agency_ca/agencyC/* ~/generator-C/meta/
echo "Successfully Copied agencyC  certificate to the deployment folder. " >> ~/webase-deploy/lab3.log
echo "---                                                                " >> ~/webase-deploy/lab3.log 

echo "###################################################################"
echo "Successfully executed the script file labscript1.sh                "
echo "###################################################################"
echo "Now execute the script file labscript2.sh                          "
echo "###################################################################"
