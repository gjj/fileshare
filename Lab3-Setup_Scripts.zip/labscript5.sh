cd /home/fisco-bcos/generator-B/nodeB
./start_all.sh

cd /home/fisco-bcos/generator-C/nodeC
./start_all.sh

echo "###################################################################"
echo "Successfully executed the script file labscript5.sh                "
echo "###################################################################"
