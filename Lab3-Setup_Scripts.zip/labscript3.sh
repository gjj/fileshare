echo "###################################################################" >> ~/webase-deploy/lab3.log
echo "# Generate the genesis block                                       " >> ~/webase-deploy/lab3.log
echo "###################################################################" >> ~/webase-deploy/lab3.log
cd ~/generator-A
./generator --create_group_genesis ./group
echo "Successfully generated the genesis block                           " >> ~/webase-deploy/lab3.log
echo "---                                                                " >> ~/webase-deploy/lab3.log

cp ./group/group.1.genesis ~/generator-B/meta
cp ./group/group.1.genesis ~/generator-C/meta

cd meta
cp ../../generator-B/meta/peersA.txt ./
cat peers*.txt > peersAll.txt

cp peersAll.txt ~/generator-B/meta/
cp peersAll.txt ~/generator-C/meta/

echo "Successfully copied the genesis block to manufacturer and supplier " >> ~/webase-deploy/lab3.log
echo "---                                                                " >> ~/webase-deploy/lab3.log
cd ~/generator-A
./generator --build_install_package ./meta/peersAll.txt ./nodeA
ls ./nodeA
echo "Starting the node"
bash ./nodeA/start_all.sh
echo "Starting the node                                                  " >> ~/webase-deploy/lab3.log
echo "---                                                                " >> ~/webase-deploy/lab3.log

cd ~/generator-B
./generator --build_install_package ./meta/peersAll.txt ./nodeB
bash ./nodeB/start_all.sh
echo "Successfully generated the nobe B                                  " >> ~/webase-deploy/lab3.log
echo "---                                                                " >> ~/webase-deploy/lab3.log

cd ~/generator-C
./generator --build_install_package ./meta/peersAll.txt ./nodeC
bash ./nodeC/start_all.sh
echo "Successfully generated the nobe C                                  " >> ~/webase-deploy/lab3.log
echo "---                                                                " >> ~/webase-deploy/lab3.log

echo "Checking the node processes                                        " >> ~/webase-deploy/lab3.log
ps -ef | grep fisco
tail -f ./node*/node*/log/log* | grep +++

echo "###################################################################"
echo "Successfully executed the script file labscript3.sh                "
echo "###################################################################"
echo "Now execute the script file labscript4.sh                          "
echo "###################################################################"
